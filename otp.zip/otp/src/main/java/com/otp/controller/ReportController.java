package com.otp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.otp.model.Customer;
import com.otp.model.Payment;
import com.otp.service.ReportService;
import com.otp.util.CSVReader;
import com.otp.util.CSVWriter;

@RestController
public class ReportController {

    @Autowired
    private ReportService reportService;

    @Autowired
    private CSVReader csvReader;

    @Autowired
    private CSVWriter csvWriter;

    @GetMapping("/generate-reports")
    public String generateReports() {
        List<Customer> customers = csvReader.readCustomers("customer.csv");
        List<Payment> payments = csvReader.readPayments("payments.csv");

        List<String> customerReport = reportService.generateCustomerReport(customers, payments);
        csvWriter.writeReport01("report01.csv", customerReport);

        List<String> topCustomers = reportService.getTopCustomers(customerReport);
        csvWriter.writeTopCustomers("top.csv", topCustomers);
        List<String> webshopReport = reportService.generateWebshopReport(payments);
        
        csvWriter.writeReport02("report02.csv", webshopReport);

        return "Reports generated successfully!";
    }
}
