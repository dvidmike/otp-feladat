package com.otp.model;

import java.time.LocalDate;

public class Payment {
    private String webshopId;
    private String customerId;
    private PaymentType paymentType;
    private double amount;
    private String accountNumber;
    private String cardNumber;
    private LocalDate paymentDate;

    public Payment(String webshopId, String customerId, PaymentType paymentType, double amount, String accountNumber, String cardNumber, LocalDate paymentDate) {
        this.webshopId = webshopId;
        this.customerId = customerId;
        this.paymentType = paymentType;
        this.amount = amount;
        this.accountNumber = accountNumber;
        this.cardNumber = cardNumber;
        this.paymentDate = paymentDate;
    }

    public String getWebshopId() {
        return webshopId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public PaymentType getPaymentType() {
        return paymentType;
    }

    public double getAmount() {
        return amount;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public LocalDate getPaymentDate() {
        return paymentDate;
    }
}
