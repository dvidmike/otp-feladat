package com.otp.model;

public enum PaymentType {
    CARD, TRANSFER
}
