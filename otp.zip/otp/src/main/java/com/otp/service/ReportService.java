package com.otp.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.otp.model.Customer;
import com.otp.model.Payment;
import com.otp.model.PaymentType;


@Service
public class ReportService {

    public List<String> generateCustomerReport(List<Customer> customers, List<Payment> payments) {
        Map<String, Double> customerTotal = new HashMap<>();

        for (Payment payment : payments) {
            String key = payment.getWebshopId() + "-" + payment.getCustomerId();
            customerTotal.put(key, customerTotal.getOrDefault(key, 0.0) + payment.getAmount());
        }

        List<String> reportData = new ArrayList<>();
        for (Customer customer : customers) {
            String key = customer.getWebshopId() + "-" + customer.getCustomerId();
            double totalAmount = customerTotal.getOrDefault(key, 0.0);
            reportData.add(customer.getName() + ";" + customer.getAddress() + ";" + totalAmount);
        }

        return reportData;
    }

    public List<String> generateWebshopReport(List<Payment> payments) {
        Map<String, double[]> webshopTotals = new HashMap<>();

        for (Payment payment : payments) {
            double[] totals = webshopTotals.getOrDefault(payment.getWebshopId(), new double[2]);
            if (payment.getPaymentType() == PaymentType.CARD) {
                totals[0] += payment.getAmount();
            } else {
                totals[1] += payment.getAmount();
            }
            webshopTotals.put(payment.getWebshopId(), totals);
        }

        return webshopTotals.entrySet().stream()
                .map(entry -> entry.getKey() + ";" + entry.getValue()[0] + ";" + entry.getValue()[1])
                .collect(Collectors.toList());
    }

    public List<String> getTopCustomers(List<String> reportData) {
        return reportData.stream()
                .sorted((a, b) -> Double.compare(Double.parseDouble(b.split(";")[2]), Double.parseDouble(a.split(";")[2])))
                .limit(2)
                .collect(Collectors.toList());
    }
}
