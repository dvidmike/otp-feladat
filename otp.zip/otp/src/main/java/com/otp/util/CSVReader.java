package com.otp.util;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.otp.model.Customer;
import com.otp.model.Payment;
import com.otp.model.PaymentType;

@Component
public class CSVReader {

    public List<Customer> readCustomers(String fileName) {
        List<Customer> customers = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(getClass().getClassLoader().getResourceAsStream(fileName)))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(";");
                if (values.length != 4) {
                    Logger.logError("Invalid customer record: " + line);
                    continue;
                }
                customers.add(new Customer(values[0], values[1], values[2], values[3]));
            }
        } catch (IOException e) {
            Logger.logError("Error reading customers file: " + e.getMessage());
        }
        return customers;
    }

    public List<Payment> readPayments(String fileName) {
        List<Payment> payments = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(getClass().getClassLoader().getResourceAsStream(fileName)))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(";");
                if (values.length != 7) {
                    Logger.logError("Invalid payment record: " + line);
                    continue;
                }
                try {
                    PaymentType paymentType = values[2].equalsIgnoreCase("card") ? PaymentType.CARD : PaymentType.TRANSFER;
                    double amount = Double.parseDouble(values[3]);
                    LocalDate paymentDate;
                    try {
                        paymentDate = LocalDate.parse(values[6], DateTimeFormatter.ofPattern("yyyy.MM.dd"));
                    } catch (DateTimeParseException e) {
                        Logger.logError("Invalid date format in payment record: " + line);
                        continue;
                    }
                    String bankAccount = paymentType == PaymentType.TRANSFER ? values[4] : null;
                    String cardNumber = paymentType == PaymentType.CARD ? values[5] : null;
                    payments.add(new Payment(values[0], values[1], paymentType, amount, bankAccount, cardNumber, paymentDate));
                } catch (NumberFormatException e) {
                    Logger.logError("Invalid amount format in payment record: " + line);
                } catch (Exception e) {
                    Logger.logError("Error parsing payment record: " + line);
                }
            }
        } catch (IOException e) {
            Logger.logError("Error reading payments file: " + e.getMessage());
        }
        return payments;
    }
}
